export interface AbpValidationError {
    name: string;
    localizationKey: string;
    propertyKey: string;
}
